


<li class="list-group-item p-0 pt-2 pb-2" style="border: none">
    <h5>
        <i class="fa fa-<?php echo e($icon); ?> mr-2"></i>
        <?php echo e($title); ?>

    </h5>
    <p class="text-muted"><?php echo e($slot); ?></p>
</li><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/components/contact-list.blade.php ENDPATH**/ ?>