

<?php $__env->startSection('style'); ?>
<style>
    .card {
        display: inline-block
    }

    .center {
        display: flex;
        flex-direction: column;
        justify-content: center;
        /* align-items: center; */
    }

    .flex-container {
        display: flex;
        flex-wrap: wrap;
        flex-direction: row;
    }

    .overlay {
        position: absolute;
        bottom: 0;
        background: rgb(0, 0, 0);
        background: rgba(0, 0, 0, 0.5); /* Black see-through */
        color: #f1f1f1;
        width: 100%;
        opacity:1;
        color: white;
        padding: 10px;
    }

    .form-konsumen {
        position: relative;
    }
    @media  only screen and (min-width: 992px){
        .form-konsumen {
            position: absolute;
            z-index: 999;
            top: -80px
        }
        .logo-container {
            padding: 0px 0px 128px 168px;
        }
    }

    /* .form-konsumen, .form-konsumen .card-header  {
        border-top: none;
    } */

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Home BFI Syariah'); ?>

<?php $__env->startSection('content'); ?>

 <?php if (isset($component)) { $__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Navbar::class, []); ?>
<?php $component->withName('layout.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0)): ?>
<?php $component = $__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0; ?>
<?php unset($__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<section>
<div class="jumbotron jumbotron-fluid center" style="background-image: url('<?php echo e(asset('img/autumn.jpg')); ?>'); background: rgba(0, 0, 0, 0.5);min-height: 500px; ">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 center text-white">
                <h1 class="display-4" style="word-wrap: break-word">#JauhLebihTenang</h1><br>
                <p class="lead">Dengan pembiayaan tanpa denda dan tanpa provisi di BFI Finance Syariah menggunakan akad dan proses syariah yang transaparan.</p>
                
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="card shadow form-konsumen">
                    <div class="card-header bg-primary p-1 m-0"></div>
                    <div class="card-body">
                        <div class="container">
                            <h2 class="text-center" style="padding-left: 40px; padding-right: 40px; margin-bottom: 32px;">Isi formulir untuk pengajuan</h2>
                            <form id="form" action="" method="POST">
                                <div class="form-group">
                                    <label for="nama_lengkap">Nama Lengkap</label>
                                    <input type="text" class="form-control" name="nama_lengkap" id="nama_lengkap" required>
                                </div>
                                <div class="form-group">
                                    <label for="email">Alamat Email</label>
                                    <input type="email" class="form-control" name="email" id="email" required>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <label for="no_hp">Nomor Handphone</label>
                                        <input type="no_hp" class="form-control" name="no_hp" id="no_hp" required>
                                    </div>
                                    <div class="col">
                                        <label for="cabang_terdekat">Cabang Terdekat</label>
                                        <input type="text" class="form-control" name="cabang_terdekat" id="cabang_terdekat" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="jaminan_mobil">Mobil yang dijaminkan</label>
                                    <input type="text" class="form-control" name="jaminan_mobil" id="jaminan_mobil" required>
                                </div>
                                <div class="form-group">
                                    <label for="tujuan_pembiayaan">Tujuan Pembiayaan</label>
                                    <input type="text" class="form-control" name="tujuan_pembiayaan" id="tujuan_pembiayaan" required>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="agreement" required onclick="checkedAgreement()">
                                    <label class="form-check-label" for="agreement"><small class="text-muted">Saya menyetujui untuk dihubungi oleh BFI Finance melalui telepon dan berlangganan email produk</small></label>
                                </div>
                                <button id="kirimData" type="submit" class="btn btn-primary btn-lg btn-block mt-4" disabled>Kirim Data</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>


<section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 col-md-6">
                <div class="logo-container">
                    <p class="mb-0">Travel Partner Kami: </p>
                    <div id="image-container">
                        
                    </div>
                </div>
            </div>
            <div class="offset-6">

            </div>
        </div>
    </div>
</section>


<section>
    <div class="jumbotron" style="height: 200px;background-image: url('<?php echo e(asset('img/autumn.jpg')); ?>')">
    </div>
</section>


<section class="pt-4 pb-4">
    <div class="container">
        <h2 class="text-center p-4">Paket Trip Pilihan</h2>
        <div class="row">
            <div class="col-lg-4 col-md-4 mr-0 card p-0">
                <img class="card-img-top p-0 m-0" src="<?php echo e(asset("img/autumn.jpg")); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Pattaya Island Tour</h5>
                        <p class="card-text">Wujudkan impian ke tanah suci bersama My Ihram. Kami bekerjasama dengan AliaGo Tour and Travel mengadakan perjalanan umroh selama 9 hari.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
            </div>
            <div class="col-lg-8 col-md-8 col-12 pt-0 pl-2">
                <div class="flex-container">
                     <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
            </div>
        </div>
    </div>
</section>
    


 <?php if (isset($component)) { $__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Footbar::class, []); ?>
<?php $component->withName('layout.footbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6)): ?>
<?php $component = $__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6; ?>
<?php unset($__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script>
        //get reference
        var database = firebase.database();
        var formRef = database.ref('form');

        //get timestamp UTC
        var d = new Date();
        var date = d.getUTCDate();
        var month = d.getUTCMonth();
        var year = d.getUTCFullYear();
        var hours = d.getUTCHours();
        var minutes = d.getUTCMinutes();
        var seconds = d.getUTCSeconds();

        var fulldate = `${date}-${month}-${year} ${hours}:${minutes}:${seconds}`;

        //get element
        var form                = document.getElementById("form");
        var nama_lengkap        = document.getElementById("nama_lengkap");
        var email               = document.getElementById("email");
        var no_hp               = document.getElementById("no_hp");
        var cabang_terdekat     = document.getElementById("cabang_terdekat");
        var jaminan_mobil       = document.getElementById("jaminan_mobil");
        var tujuan_pembiayaan   = document.getElementById("tujuan_pembiayaan");
        
        var kirimData   = document.getElementById("kirimData");

        const insertData = () => {
            formRef.push({
                nama_lengkap        : nama_lengkap.value,
                email               : email.value,
                no_hp               : no_hp.value,
                cabang_terdekat     : cabang_terdekat.value,
                jaminan_mobil       : jaminan_mobil.value,
                tujuan_pembiayaan   : tujuan_pembiayaan.value,
                created_at          : fulldate
            }, function(error){
                if(error){
                    console.log(error);
                } else {
                    // Memunculkan alert success
                    swal("Good job!", "Data telah terkirim!", "success");
                    // Enable button kirim
                    kirimData.removeAttribute("disabled");
                    // 
                    kirimData.innerHTML = "Kirim Data";

                    form.reset();
                }
            })
        }

        form.addEventListener("submit", function(event){
            event.preventDefault();
            
            kirimData.setAttribute("disabled", "disabled");
            kirimData.innerHTML = "Mengirim...";
            
            insertData();
        })
        
        const checkedAgreement = () => {
            var checkBox = document.getElementById("agreement");
            
            if(checkBox.checked)
                kirimData.removeAttribute("disabled")
            else
                kirimData.setAttribute("disabled", "disabled");
        }
    </script>

    
<script>
    //get element
    var listLogo = document.querySelector("#image-container");
    //untuk menampung list gambar
    var content = '';

    // Get Files List
    var logoRef = firebase.storage().ref('mitra/');
    logoRef.listAll().then((res) => {
        res.items.forEach((itemRef) => {
        // console.log(itemRef.name);
        logoRef.child(itemRef.name).getDownloadURL().then((url) => {

        content += ` <?php if (isset($component)) { $__componentOriginalb8f4644ab75579615378a85eed82aa3e681e5ed2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Partner::class, ['image' => '${url}']); ?>
<?php $component->withName('partner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalb8f4644ab75579615378a85eed82aa3e681e5ed2)): ?>
<?php $component = $__componentOriginalb8f4644ab75579615378a85eed82aa3e681e5ed2; ?>
<?php unset($__componentOriginalb8f4644ab75579615378a85eed82aa3e681e5ed2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> `;
        listLogo.innerHTML = content;
        console.log(url);
        }).catch((error) => {
            console.log(error);
        });
        })
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/home.blade.php ENDPATH**/ ?>