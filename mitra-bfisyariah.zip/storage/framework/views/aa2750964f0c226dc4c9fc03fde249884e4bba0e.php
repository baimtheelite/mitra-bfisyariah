<header class="fixed-top">
  <div class="bg-primary" style="padding: 3px"></div>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
    <a class="navbar-brand" href="<?php echo e(url("/")); ?>">
        <img src="<?php echo e(asset("img/bfi.png")); ?>" alt="bfi" style="height: 35px; width: auto">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link <?php echo e((request()->segment(1) == 'explore') ? 'active' : ''); ?>" href="#">Explore</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e((request()->segment(1) == 'promo') ? 'active' : ''); ?>" href="#">Promo</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e((request()->segment(1) == 'kontak') ? 'active' : ''); ?>" href="<?php echo e(url("kontak")); ?>">Kontak</a>
          </li>
        </ul>
        <form class="form-inline my-2 my-lg-0">
          
          <a href="https://wa.me/6289655333987?text=Hi,%20saya%20ingin%20bekerjasama%20dengan%20BFI%20Syariah"
          class="btn btn-success">Whatsapp</a>
        </form>
      </div>
    </div>
  </nav>
</header><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/components/layout/navbar.blade.php ENDPATH**/ ?>