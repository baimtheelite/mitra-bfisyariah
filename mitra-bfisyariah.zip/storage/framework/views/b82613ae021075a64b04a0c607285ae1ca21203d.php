<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

  
   <?php if (isset($component)) { $__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\ContentHeader::class, ['title' => 'Dashboard']); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php if (isset($component)) { $__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\BreadcrumbItem::class, ['url' => '/admin-wp','item' => 'Dashboard']); ?>
<?php $component->withName('admin.breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e)): ?>
<?php $component = $__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e; ?>
<?php unset($__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
   <?php if (isset($__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6)): ?>
<?php $component = $__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6; ?>
<?php unset($__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
  
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <button class="btn btn-primary" onclick="addData()">click me mon ami</button>
          <div class="card">
            <div class="card-header border-0">
              <h3 class="card-title">Data Form</h3>
            </div>
            <div class="card-body table-responsive p-0">
              <table id="data-form" class="table table-bordered table-striped">
                <thead>
                <tr id="column-data">
                  
                </tr>
                </thead>
                <tbody id="list-data">
                  
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

    // var dataTable = $("#data-form").dataTable();
    //get element
    var listData = document.getElementById("list-data");
    var content = [];
    var formRef = firebase.database().ref('form/');
    
    
    formRef.on('value', function(snapshot) {

    const distinct = (value, index, self) => {
      return self.indexOf(value) === index;
    }

    const arr = [];

    snapshot.forEach((child) => {
      const keys = Object.keys(child.val());
      keys.forEach((key) => {
        arr.push(key)
      });

    });

    const distinctKeys = arr.filter(distinct);
    console.log(distinctKeys);

    var column = '';
    distinctKeys.forEach((key) => {
      column += `<td>${key}</td>`;
    })
    $("#column-data").html(column);
    console.log(column);
  })

  
</script>  
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>