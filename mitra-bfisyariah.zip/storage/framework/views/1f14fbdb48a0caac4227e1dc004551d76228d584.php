<div class="card text-center mb-2 flex-fill" style="border: none; border-radius: 0">
    <div class="card-body">
        
        <i class="fa fa-2x fa-dollar-sign"></i>
        <p class="card-title text-capitalize text-bold"><?php echo e($title); ?></p>
        <p class="card-text" style="color: #9BA5A7; font-size: 14px"><?php echo e($text); ?></p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/components/card-feature.blade.php ENDPATH**/ ?>