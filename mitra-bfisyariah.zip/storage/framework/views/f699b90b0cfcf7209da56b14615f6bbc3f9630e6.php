<!-- Main header -->
<header class="header">

    <div class="main-header">
        <div class="main-menu-wrap">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-xl-3 col-lg-3 col-md-4 col-6">

                        <div class="logo">
                            <a href="index.html">
                                <img src="<?php echo e(asset("img/bfi.png")); ?>" data-rjs="2" alt="BFI Syariah" width="150px"
                                    height="75px">
                            </a>
                        </div>

                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-4 col-6 menu-button">
                        <div class="menu--inner-area clearfix">
                            <div class="menu-wraper">
                                <nav>
                                    <div class="header-menu dosis">
                                        <ul>
                                            <li><a href="#produk">Produk</a></li>
                                            <li><a href="#kontak">Kontak</a></li>
                                        </ul>
                                    </div> 
                                    <div class="mobile text-right">
                                        <a href="https://wa.me/6289655333987?text=Hi,%20saya%20ingin%20bekerjasama%20dengan%20BFI%20Syariah"
                                            class="btn btn-resize">Whatsapp</a>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-5 d-md-block d-none">
                        <div class="urgent-call text-right">
                            <a href="https://wa.me/6289655333987?text=Hi,%20saya%20ingin%20bekerjasama%20dengan%20BFI%20Syariah"
                                class="btn btn-resize">Whatsapp</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</header>
<!-- End of Main header --><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/components/layout/header.blade.php ENDPATH**/ ?>