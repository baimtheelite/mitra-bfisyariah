

<?php $__env->startSection('style'); ?>
    <style>
        .center {
            /* padding-top: 10%;
            padding-bottom: 10%; */
            padding-left: 5%;
            padding-right: 5%;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center; 
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Success'); ?>

<?php $__env->startSection('content'); ?>

 <?php if (isset($component)) { $__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Navbar::class, []); ?>
<?php $component->withName('layout.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0)): ?>
<?php $component = $__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0; ?>
<?php unset($__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<div class="center text-center">
    <i class="fas fa-check-circle fa-4x mb-4 text-success"></i>
    <h1 class="text-success">Terima kasih!</h1>
    <p>Tim BFI Syariah akan menghubungi Anda dalam waktu singkat.</p>
</div>


 <?php if (isset($component)) { $__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Footbar::class, []); ?>
<?php $component->withName('layout.footbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6)): ?>
<?php $component = $__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6; ?>
<?php unset($__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/success.blade.php ENDPATH**/ ?>