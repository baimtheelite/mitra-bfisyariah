

<?php $__env->startSection('title', 'Pages'); ?>

<?php $__env->startSection('style'); ?>
    <style>
        img {
            width: auto;
            height: 100px;
            object-fit: cover;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 <?php if (isset($component)) { $__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\ContentHeader::class, ['title' => 'Page']); ?>
<?php $component->withName('admin.content-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php if (isset($component)) { $__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\BreadcrumbItem::class, ['url' => '/admin-wp','item' => 'Dashboard']); ?>
<?php $component->withName('admin.breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e)): ?>
<?php $component = $__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e; ?>
<?php unset($__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     <?php if (isset($component)) { $__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\BreadcrumbItem::class, ['url' => '/admin-wp/page','item' => 'Page']); ?>
<?php $component->withName('admin.breadcrumb-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e)): ?>
<?php $component = $__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e; ?>
<?php unset($__componentOriginal0413f0493259d02c4e038e7dab74caf54422b85e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
   <?php if (isset($__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6)): ?>
<?php $component = $__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6; ?>
<?php unset($__componentOriginal7908594b173aff72a7f86e3602695e9bbb07e8e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<div class="content">
    <div class="container-fluid">
      <div class="card card-primary">
        <div class="card-header">
          <h3 class="card-title">Page Settings</h3>
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md-12 col-lg-12">
                <h4>Logo</h4>
                <div id="list-logo">
                    
                </div>
            </div>
          </div>
          </div>
          <div class="card-footer">
          </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
    //get element
    var listLogo = document.getElementById("list-logo");
    //untuk menampung list gambar
    var content = '';

    // Get Files List
    var logoRef = firebase.storage().ref('mitra/');
    logoRef.listAll().then((res) => {
        res.items.forEach((itemRef) => {
        // console.log(itemRef.name);
        logoRef.child(itemRef.name).getDownloadURL().then((url) => {

        content += `<img src="${url}">`;
        listLogo.innerHTML = content;
        console.log(url);
        }).catch((error) => {
            console.log(error);
        });
        })
    })
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/admin/page.blade.php ENDPATH**/ ?>