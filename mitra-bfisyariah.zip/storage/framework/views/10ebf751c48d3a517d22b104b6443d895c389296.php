

<?php $__env->startSection('title', 'Kontak BFI Syariah'); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .center {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center; 
        }

        .overlay {
            position: absolute;
            bottom: 0;
            background: rgb(0, 0, 0);
            background: rgba(0, 0, 0, 0.5); /* Black see-through */
            color: #f1f1f1;
            width: 100%;
            opacity:1;
            color: white;
            padding: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 <?php if (isset($component)) { $__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Navbar::class, []); ?>
<?php $component->withName('layout.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0)): ?>
<?php $component = $__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0; ?>
<?php unset($__componentOriginalde5be1b07ecba636fefe72889fa78f2d1c8ad0a0); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<section>
    <div class="jumbotron jumbotron-fluid center" style="background: rgba(0, 0, 0, 5); min-height: 500px; background-color: rgba(0, 0, 0, 0.8) ">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 center text-white">
                    <h1 class="mx-5" style="font-size: 3.5rem">#JauhLebihTenang</h1><br>
                    <p class="lead">Dengan pembiayaan tanpa denda dan tanpa provisi di BFI Finance Syariah menggunakan akad dan proses syariah yang transaparan.</p>
                    
                </div>
            </div>
        </div>
    </div>
</section>


<section>
    <div class="container">
        <div class="row mb-4">
            <div class="col-lg-6 col-md-6">
                <h2 class="pt-2 pb-4">Hubungi Kami</h2>
                <ul class="list-group">
                     <?php if (isset($component)) { $__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ContactList::class, ['icon' => 'home','title' => 'Alamat']); ?>
<?php $component->withName('contact-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        BFI Tower, Sunburst CBD Lot 1.2 <br>
                        Jalan Kapten Soebijanto Djojohadikusumo <br>
                        BSD City - Tangerang Selatan 15322
                     <?php if (isset($__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25)): ?>
<?php $component = $__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25; ?>
<?php unset($__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ContactList::class, ['icon' => 'phone','title' => 'Telepon']); ?>
<?php $component->withName('contact-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        Telepon:(021) 2965 0300<br>
                        Whatsapp : 0811977500
                     <?php if (isset($__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25)): ?>
<?php $component = $__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25; ?>
<?php unset($__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                     <?php if (isset($component)) { $__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ContactList::class, ['icon' => 'envelope','title' => 'Alamat']); ?>
<?php $component->withName('contact-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
                        cs.bfisyariah@bfi.co.id
                     <?php if (isset($__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25)): ?>
<?php $component = $__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25; ?>
<?php unset($__componentOriginal380c4cab14a1f29f10719d2ab8a03a6259faed25); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </ul>
            </div>
            <div class="col-lg-6 col-md-6">
                <h2 class="pt-2 pb-4">Beritahu Kami Pesan Anda</h2>
                <form id="contact-form" action="#" method="POST">
                    <div class="form-group">
                        <label for="nama_lengkap">Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama_lengkap" id="nama_lengkap" required>
                    </div>
                    <div class="form-group">
                        <label for="no_whatsapp">Nomor Whatsapp</label>
                        <input type="text" class="form-control" name="no_whatsapp" id="no_whatsapp" required>
                    </div>
                    <div class="form-group">
                        <label for="pesan">Pesan</label>
                        <textarea class="form-control" name="pesan" id="pesan" cols="30" rows="5" required></textarea>
                    </div>
                    <button id="kirimData" type="submit" class="btn btn btn-outline-primary mt-4" style="width: 110px">Kirim</button>
                </form>
            </div>
        </div>
    </div>
</section>


<section style="background: #CDD2D5; padding: 100px">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12">
                <div class="text-center">
                    <a href="https://wa.me/6289655333987?text=Hi,%20saya%20ingin%20bekerjasama%20dengan%20BFI%20Syariah" class="btn btn-outline-success mr-4 mb-2 d-inline-block" style="width: 150px">Whatsapp</a>
                    <a href="#" class="btn btn-success mr-4 mb-2 d-inline-block" style="width: 150px">Ajukan</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="pt-4 pb-4">
    <div class="container">
        <h2 class="text-center p-4">Paket Cicilan Tanpa Denda</h2>
        <div class="row">
            <div class="col-lg-4 col-md-4 mr-0 card p-0">
                <img class="card-img-top p-0 m-0" src="<?php echo e(asset("img/autumn.jpg")); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title">Pattaya Island Tour</h5>
                        <p class="card-text">Wujudkan impian ke tanah suci bersama My Ihram. Kami bekerjasama dengan AliaGo Tour and Travel mengadakan perjalanan umroh selama 9 hari.</p>
                        <a href="#" class="btn btn-primary">Go somewhere</a>
                    </div>
            </div>
            <div class="col-lg-8 col-md-8 col-12" style="padding-left: 20px;">
                
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-6" style="padding-left: 0px; padding-right: 0px">
                             <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-lg-4 col-md-4 col-6" style="padding-left: 0px; padding-right: 0px">
                             <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-lg-4 col-md-4 col-6" style="padding-left: 0px; padding-right: 0px">
                             <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-lg-4 col-md-4 col-6" style="padding-left: 0px; padding-right: 0px">
                             <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-lg-4 col-md-4 col-6" style="padding-left: 0px; padding-right: 0px">
                             <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                        <div class="col-lg-4 col-md-4 col-6" style="padding-left: 0px; padding-right: 0px">
                             <?php if (isset($component)) { $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PaketTrip::class, ['judul' => 'Umroh Super Saver Double','harga' => 'Rp 810,000 / Bulan']); ?>
<?php $component->withName('paket-trip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12)): ?>
<?php $component = $__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12; ?>
<?php unset($__componentOriginal72b12ca5ac164cf4993a3df7bf793478c668fd12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                    
            </div>
        </div>
    </div>
</section>


 <?php if (isset($component)) { $__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout\Footbar::class, []); ?>
<?php $component->withName('layout.footbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6)): ?>
<?php $component = $__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6; ?>
<?php unset($__componentOriginal3cf054ae87161ee95bcf6080f409a13b3e4c11e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var database = firebase.database();
        var contactFormRef = database.ref('contact_form');

        //get element
        var kirimData   = document.getElementById("kirimData");
        $("#contact-form").on("submit", function(){
            event.preventDefault();
            
            kirimData.setAttribute("disabled", "disabled");
            kirimData.innerHTML = "Mengirim...";

            // variabel kosong untuk menampung input form
            var dataObject = {};
            // menangkap (get) attribute name dan value dari form input
            var data = $(this).serializeArray();
            // membuat pasangan key dan value ke dalam 1 object
            data.forEach((item, index) => {
                eval("dataObject." + item['name'] + " = item['value']");
            })
            
            contactFormRef.push(dataObject, function(error){
                if(error){
                    console.log(error);
                } else {
                    // Memunculkan alert success
                    swal("Good job!", "Data telah terkirim!", "success");
                    // Enable button kirim
                    kirimData.removeAttribute("disabled");
                    // 
                    kirimData.innerHTML = "Kirim Data";

                    form.reset();
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mitra-bfisyariah\resources\views/kontak.blade.php ENDPATH**/ ?>