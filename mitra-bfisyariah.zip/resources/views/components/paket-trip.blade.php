<div class="card mb-1 shadow text-white">
  <img class="card-img-top" src="{{ asset("img/autumn.jpg") }}" alt="Card image cap" style="width: auto; height: 200px">
    <div class="overlay">
      <small class="card-text">Umroh Super Saver Double</small>
      <small class="card-text">Rp 918,222 / Bulan</small>
    </div>
  </div>