<footer class="p-4">
    <div class="container">
        <div class="row mt-4">
            <div class="col-lg-3 col-md-3">
            <img class="mb-2" src="{{ asset("img/bfi.png") }}" alt="" style="width: auto; height: 50px">
            <p>#JauhLebihTenang pembiayaan dengan
                BFI Finance Syariah, akad murni jual beli,
                tanpa denda dan tanpa provisi</p>
            </div>
            <div class="col-lg-3 col-md-3">

            </div>
            <div class="col-lg-3 col-md-3">

            </div>
            <div class="col-lg-3 col-md-3">
                <p>Ikuti Kami di Media Sosial</p>
                <ul class="list-inline">
                    <li class="list-inline-item"><a href="#"><i class="fab fa-instagram" style="font-size: 25px;"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-facebook" style="font-size: 25px;"></i></a></li>
                    <li class="list-inline-item"><a href="#"><i class="fab fa-youtube" style="font-size: 25px;"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>